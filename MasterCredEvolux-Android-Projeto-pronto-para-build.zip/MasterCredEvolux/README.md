# MasterCred evolux — demonstração Android

Este é um projeto Android Studio com interface local em WebView. Todas as funções financeiras são **simulações locais**.

## O que funciona
- Saldo demonstrativo com ocultar/mostrar
- Pix simulado: enviar e receber
- Transferência interna simulada
- Extrato com histórico local
- Cartão virtual ilustrativo e bloqueio visual
- Área de crédito demonstrativa
- Dados de demonstração persistidos no aparelho via armazenamento local

## Aviso importante
O aplicativo não é banco, instituição de pagamento ou correspondente bancário. Não realiza Pix real, não consulta INSS, não aprova crédito e não movimenta dinheiro. Os saldos, chaves, cartões e transações são fictícios. O aviso DEMONSTRAÇÃO aparece permanentemente na interface.

## Gerar APK
1. Abra a pasta `MasterCredEvolux` no Android Studio (versão recente).
2. Aguarde a sincronização do Gradle.
3. Se solicitado, instale Android SDK Platform 35 e Build Tools.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

O ambiente onde este projeto foi preparado não possui Android SDK/Gradle instalados; por isso entrego o projeto-fonte pronto para abrir e compilar no Android Studio, não um APK já compilado.
